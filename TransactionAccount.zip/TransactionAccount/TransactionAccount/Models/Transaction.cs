﻿namespace TransactionAccount.Models
{
    public class Transaction
    {
        public int Id { get; set; }
        public string TransactionType { get; set; }

        public int Amount { get; set; }
        public DateTime TransactedAt { get; set; }
        public int StartingBalance { get; set; }
        public int EndingBalance { get; set; }
    }
}
