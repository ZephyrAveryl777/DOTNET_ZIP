﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TransactionAccount.Models;

namespace TransactionAccount.Data
{
    public class TransactionAccountContext : DbContext
    {
        public TransactionAccountContext (DbContextOptions<TransactionAccountContext> options)
            : base(options)
        {
        }

        public DbSet<TransactionAccount.Models.Transaction> Transaction { get; set; } = default!;
    }
}
