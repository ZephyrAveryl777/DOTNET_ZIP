﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ATMCard.Data;
using ATMCard.Models;

namespace ATMCard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ATMCardcsController : ControllerBase
    {
        private readonly ATMCardContext _context;

        public ATMCardcsController(ATMCardContext context)
        {
            _context = context;
        }

        // GET: api/ATMCardcs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ATMCardcs>>> GetATMCardcs()
        {
            return await _context.ATMCardcs.ToListAsync();
        }

        // GET: api/ATMCardcs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ATMCardcs>> GetATMCardcs(int id)
        {
            var aTMCardcs = await _context.ATMCardcs.FindAsync(id);

            if (aTMCardcs == null)
            {
                return NotFound();
            }

            return aTMCardcs;
        }

        // PUT: api/ATMCardcs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutATMCardcs(int id, ATMCardcs aTMCardcs)
        {
            if (id != aTMCardcs.Id)
            {
                return BadRequest();
            }

            _context.Entry(aTMCardcs).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ATMCardcsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ATMCardcs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ATMCardcs>> PostATMCardcs(ATMCardcs aTMCardcs)
        {
            _context.ATMCardcs.Add(aTMCardcs);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetATMCardcs", new { id = aTMCardcs.Id }, aTMCardcs);
        }

        // DELETE: api/ATMCardcs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteATMCardcs(int id)
        {
            var aTMCardcs = await _context.ATMCardcs.FindAsync(id);
            if (aTMCardcs == null)
            {
                return NotFound();
            }

            _context.ATMCardcs.Remove(aTMCardcs);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ATMCardcsExists(int id)
        {
            return _context.ATMCardcs.Any(e => e.Id == id);
        }
    }
}
