﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ATMCard.Models;

namespace ATMCard.Data
{
    public class ATMCardContext : DbContext
    {
        public ATMCardContext (DbContextOptions<ATMCardContext> options)
            : base(options)
        {
        }

        public DbSet<ATMCard.Models.ATMCardcs> ATMCardcs { get; set; } = default!;
    }
}
