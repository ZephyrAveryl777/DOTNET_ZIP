﻿namespace ATMCard.Models
{
    public class ATMCardcs
    {
        public int Id { get; set; }
        public string? PINCode { get; set; }

        public string? CardNumber { get; set; }

        public int CustomerId { get; set; }

    }
}
