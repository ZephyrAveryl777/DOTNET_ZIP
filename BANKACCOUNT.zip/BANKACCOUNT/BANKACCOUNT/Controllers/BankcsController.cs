﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BANKACCOUNT.Data;
using BANKACCOUNT.Models;

namespace BANKACCOUNT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankcsController : ControllerBase
    {
        private readonly BANKACCOUNTContext _context;

        public BankcsController(BANKACCOUNTContext context)
        {
            _context = context;
        }

        // GET: api/Bankcs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Bankcs>>> GetBankcs()
        {
            return await _context.Bankcs.ToListAsync();
        }

        // GET: api/Bankcs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Bankcs>> GetBankcs(int id)
        {
            var bankcs = await _context.Bankcs.FindAsync(id);

            if (bankcs == null)
            {
                return NotFound();
            }

            return bankcs;
        }

        // PUT: api/Bankcs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBankcs(int id, Bankcs bankcs)
        {
            if (id != bankcs.Id)
            {
                return BadRequest();
            }

            _context.Entry(bankcs).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BankcsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Bankcs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Bankcs>> PostBankcs(Bankcs bankcs)
        {
            _context.Bankcs.Add(bankcs);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBankcs", new { id = bankcs.Id }, bankcs);
        }

        // DELETE: api/Bankcs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBankcs(int id)
        {
            var bankcs = await _context.Bankcs.FindAsync(id);
            if (bankcs == null)
            {
                return NotFound();
            }

            _context.Bankcs.Remove(bankcs);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BankcsExists(int id)
        {
            return _context.Bankcs.Any(e => e.Id == id);
        }
    }
}
