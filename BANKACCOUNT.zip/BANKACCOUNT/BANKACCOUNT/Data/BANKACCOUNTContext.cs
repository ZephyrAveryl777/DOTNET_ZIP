﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BANKACCOUNT.Models;

namespace BANKACCOUNT.Data
{
    public class BANKACCOUNTContext : DbContext
    {
        public BANKACCOUNTContext (DbContextOptions<BANKACCOUNTContext> options)
            : base(options)
        {
        }

        public DbSet<BANKACCOUNT.Models.Bankcs> Bankcs { get; set; } = default!;
    }
}
