﻿namespace BANKACCOUNT.Models
{
    public class Bankcs
    {
        public int Id { get; set; }
        public int Balance { get; set; }
        public string AccountNumber { get; set; }


        public int CustomerId { get; set; }

        public string AccountType { get; set; }
    }
}
